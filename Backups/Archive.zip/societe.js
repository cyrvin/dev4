var request = require('request');
var cheerio = require('cheerio');
var fs 		= require('fs');
var readline = require('readline');
var stream = require('stream');